State A
<button style={{
    height: 40,
    width: 120,
    color: 'red'
  }}
onMouseEnter={this.handleHoverOn}
onMouseOut={this.handleHoverOff}

>
{this.props.text}
</button>





State B
<button style={{
    height: 40,
    width: 120,
    color: 'green'
  }}
onMouseEnter={this.handleHoverOn}
onMouseOut={this.handleHoverOff}

>
{this.props.text}
</button>


  state = {
    height: 40,
    width: 120,
    color: 'red'
  }

  action dispatch - ChangeColor(Green)
  state = {
    height: 40,
    width: 120,
    color: this.action.color
  }
