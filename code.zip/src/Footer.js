import React, { Component } from 'react';

class Footer extends Component {
  constructor() {
    super();
    this.state = {
      color: 'gray',
      data: 'Default content'
    }
  }
  componentDidMount() {
    //Ajax
    //Respoms
    //this.setState(data)
    //isOpen - true -> ToggleContainer() -> false
    //isOpen - false -> ToggleContainer() -> true
  }
  render() {
    if(this.props.shouldIShowthis === false) {
      return <h3>I am hidden</h3>
    }
    return (
      <div style={{color: this.props.color}}>
        <h1 style={{ color: this.state.color }}>This is My Footer</h1>
        {
          this.props.data ? this.props.data[0] : this.state.data
        }
      </div>
    );
  }
}
export default Footer;
