import React, { Component } from 'react';
import logo from './logo.svg';
import Footer from './Footer';
import './App.css';
import MenuItem from './MenuItem'

class App extends Component {
  constructor() {
   super();
   this.state = {
     currentCount: 0,
     show: true,
     menus: ['About US', 'Contact', 'Menu 2'],
     gitRepo: [],
   }


  //  [] -> Action -> push 3 -> [3]
  //  Title = '' -> Action -> concat 'd' -> 'd'
  //  <h1>Title</h1>
  //  <h1></h1>
  //  <h1>d</h1>
   this.timer = this.timer.bind(this);
   this.FETCH_DATA = this.FETCH_DATA.bind(this)
 }


   FETCH_DATA() {
     fetch('https://api.github.com/users/google/repos')
     .then((resp) => resp.json()) // Transform the data into json
      .then((data) =>
        // Create and append the li's to the ul
        this.setState({gitRepo: data})
        )
   }

   componentDidMount() {
     //Ajax
     //Respoms
     //this.setState(data)
     this.countdown = setInterval(this.timer, 100000);

   }

   componentWillUnmount() {
     clearInterval(this.countdown);
   }

   timer() {
     const count = this.state.currentCount;
     this.setState({ currentCount: count+10 });
   }


  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Welcome to React</h1>
          <h2>Hello</h2>
        </header>
        <p className="App-intro">
          To get started, edit <code>src/App.js</code> and save to reload.
        </p>
        <Footer data={['Hello', 'World']} shouldIShowthis={true} />
        <Footer shouldIShowthis={false} />
        <Footer color={'red'} shouldIShowthis={true} />
        <Footer color={'green'} shouldIShowthis={true} />
        {
          this.state.menus.map((menu) => <MenuItem text={menu}  show={true} />)
        }
        <button onClick={this.FETCH_DATA}>Fetch Data</button>
        <ul>
        {
          this.state.gitRepo.map(({name}) => <li>{name}</li> )
        }
        </ul>

        </div>
    );
  }
}

export default App;
