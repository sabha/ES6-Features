import React , { Component } from 'react'

class MenuItem extends Component {

  constructor() {
    super();
    this.state = {
      color: 'green'
    };
    this.handleHoverOn = this.handleHoverOn.bind(this);
    this.handleHoverOff = this.handleHoverOff.bind(this);
  }

  handleHoverOn() {
    this.setState({ color: 'red' });
  }

  handleHoverOff() {
    this.setState({ color: 'green' });
  }

  // shouldComponentUpdate(){
      //3
  //   return (this.props.counter%5)
  // }

  render(){
    if(this.props.show === false) return null
    return (
      <button style={{
          height: 100,
          width: 320,
          color: this.state.color,
          fontSize: 30
        }}
      onMouseEnter={this.handleHoverOn}
      onMouseOut={this.handleHoverOff}

      >
      {this.props.text}
      {this.props.counter}
      </button>
    )
  }

}


export default MenuItem;
